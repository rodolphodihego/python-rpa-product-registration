import time
import pyautogui

time.sleep(5) 
print(pyautogui.position()) # Espera 5 segundos para você posicionar o mouse no local desejado e imprime a posição atual do mouse